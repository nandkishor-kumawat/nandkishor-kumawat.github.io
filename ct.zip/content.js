let is_underline_removed = false;
let BASE_URL = 'https://rohsikdnan.vercel.app/api/v1/gems/';

const fetchData = async (url, data) => {
    try {
        const res = await fetch(`${BASE_URL}${url}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (res.ok) {
            const response = await res.json();
            console.log(response);
            const div = document.createElement('pre');
            div.innerText = JSON.stringify(response.text.code !== 'undefined' ? response.text.code : response.text.answer, null, 2);
            navigator.clipboard.writeText(JSON.stringify(response.text.code !== 'undefined' ? response.text.code : response.text.answer, null, 2));

            Object.assign(div.style, {
                position: 'fixed',
                bottom: 0,
                left: 0,
                zIndex: '9999',
                color: 'black',
                backgroundColor: 'rgba(255, 255, 255, 0.4)',
                padding: '2px',
                maxWidth: 'max-content',
                margin: 0,
                fontSize: '10px',
                border: 'none',
                opacity: 0.7,
            });
            document.body.appendChild(div);

            const removePopup = () => {
                div.remove();
                document.removeEventListener('click', removePopup);
            };
            document.addEventListener('click', removePopup);
        }
    }
    catch (error) {
        console.error('Error sending selected text:', error);
    }
}

document.addEventListener('keydown', async function (e) {
    if (e.altKey && e.key === 'u') {
        if (!is_underline_removed) {
            const style = document.createElement('style');
            style.id = 'remove-underline';
            style.type = 'text/css';
            const selectionStyle = `::selection {background: transparent;}`;
            style.appendChild(document.createTextNode(selectionStyle));
            document.head.appendChild(style);
            is_underline_removed = true;
        } else {
            document.getElementById('remove-underline')?.remove();
            is_underline_removed = false;
        }
    }
    if (e.altKey && e.key === 'c') { // Example key combo: Alt + P
        const canvas = await html2canvas(document.body, {
            windowWidth: window.innerWidth,
            windowHeight: window.innerHeight,
            scrollX: window.scrollX,
            scrollY: 20 - window.scrollY,
            useCORS: true,
        });

        // Convert the canvas to an image
        const imgData = canvas.toDataURL("image/png");

        // Create an image element to preview or save
        const img = document.createElement('img');
        img.src = imgData;
        // img.style.position = "fixed";
        img.style.top = "10px";
        img.style.left = "10px";
        img.style.border = "1px solid black";
        img.style.zIndex = 10000;
        document.body.innerHTML = ''
        document.body.appendChild(img);
    }
    // Feature 1: Text Selection
    if (e.key === 'm' && e.ctrlKey) {
        try {
            const selectedText = window.getSelection().toString();
            await fetchData('text', { message: selectedText });

        } catch (error) {
            console.error('Error sending selected text:', error);
        }
    }

    // Feature 2: Bounding Box Capture
    if (e.ctrlKey && e.key === 'i') {
        console.log('object detection');
        let start = null;
        let end = null;

        const clickHandler = async function (event) {
            if (start === null) {
                start = { x: event.clientX, y: event.clientY };
                console.log('Start:', start);
            } else {
                end = { x: event.clientX, y: event.clientY };
                console.log('End:', end);

                const width = Math.abs(end.x - start.x);
                const height = Math.abs(end.y - start.y);
                const left = Math.min(start.x, end.x);
                const top = Math.min(start.y, end.y);

                try {
                    const visibleCanvas = await html2canvas(document.body, {
                        windowWidth: window.innerWidth,
                        windowHeight: window.innerHeight,
                        scrollX: window.scrollX,
                        scrollY: 20 - window.scrollY,
                        useCORS: true,
                    });

                    const croppedCanvas = document.createElement('canvas');
                    croppedCanvas.width = width;
                    croppedCanvas.height = height;
                    const ctx = croppedCanvas.getContext('2d');
                    ctx.drawImage(
                        visibleCanvas,
                        left, top, width, height,
                        0, 0, width, height
                    );

                    const base64 = croppedCanvas.toDataURL('image/png');
                    await fetchData('vision', { file: base64 });

                } catch (error) {
                    console.error('Error capturing image:', error);
                }

                start = null;
                end = null;
                document.removeEventListener('click', clickHandler);
            }
        };

        // Add the click listener
        document.addEventListener('click', clickHandler);
    }
});