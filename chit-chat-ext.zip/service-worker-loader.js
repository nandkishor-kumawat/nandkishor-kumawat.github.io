import './assets/Birz_WwG.js';
